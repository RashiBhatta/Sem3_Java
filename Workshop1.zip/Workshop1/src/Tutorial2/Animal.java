package Tutorial2;

public class Animal {

    // Generic method for making a sound
    public void makeSound() {
        System.out.println("The animal makes a sound.");
    }
}