package Week2;

public class Difference {
	
	    public static void main(String[] args) {
	        int num1 = 45;
	        int num2 = 32;

	        // Calculate difference and product
	        int difference = num1 - num2;
	        int product = num1 * num2;

	        // Print results
	        System.out.println("Difference: " + difference);
	        System.out.println("Product: " + product);
	    }
	

}
