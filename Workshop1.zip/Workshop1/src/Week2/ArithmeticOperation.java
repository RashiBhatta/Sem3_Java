package Week2;


	import java.util.Scanner;



	public class ArithmeticOperation {
	    public static void main(String[] args) {
	        // Create a Scanner object for user input
	        Scanner scanner = new Scanner(System.in);

	        // Prompt the user to enter the first integer
	        System.out.print("Enter the first integer: ");
	        int num1 = scanner.nextInt();

	        // Prompt the user to enter the second integer
	        System.out.print("Enter the second integer: ");
	        int num2 = scanner.nextInt();

	        // Perform and display the arithmetic operations
	        int sum = num1 + num2;
	        int difference = num1 - num2;
	        int product = num1 * num2;
	        
	        // Display the results
	        System.out.println("Addition: " + sum);
	        System.out.println("Subtraction: " + difference);
	        System.out.println("Multiplication: " + product);
	        System.out.println("Division: " + (num2 != 0));
	        // Close the scanner
	        scanner.close();
	    }
	}