package Week2;


	import java.util.Scanner;

	public class CurrencyConverter {
	    public static void main(String[] args) {
	        // Create a Scanner object to read user input
	        Scanner scanner = new Scanner(System.in);
	        
	        // Prompt the user to enter the amount in U.S. dollars
	        System.out.print("Enter the amount in U.S. dollars: ");
	        double usdAmount = scanner.nextDouble();
	        
	        // Prompt the user to enter the exchange rate
	        System.out.print("Enter the exchange rate (e.g., 74.85 for USD to INR): ");
	        double exchangeRate = scanner.nextDouble();
	        
	        // Convert the U.S. dollars to the target currency
	        double convertedAmount = usdAmount * exchangeRate;
	        
	        // Display the converted amount
	        System.out.printf("Converted amount: %.2f\n", convertedAmount);
	        
	        // Close the scanner object
	        scanner.close();
	    }
	}

