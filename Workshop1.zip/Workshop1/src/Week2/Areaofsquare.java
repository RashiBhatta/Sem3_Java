package Week2;
import java.util.Scanner;

public class Areaofsquare {
	
	
	    public static void main(String[] args) {
	        // Create a Scanner object for user input
	        Scanner scanner = new Scanner(System.in);
	        
	        // Prompt the user to enter the length of one side of the square
	        System.out.print("Enter the length of one side of the square: ");
	        
	        // Read the user input as a double
	        double side = scanner.nextDouble();
	        
	        // Calculate the area of the square
	        double area = side * side;
	        
	        // Display the result
	        System.out.println("The area of the square is: " + area);
	        
	        // Close the scanner
	        scanner.close();
	    }
	}
	