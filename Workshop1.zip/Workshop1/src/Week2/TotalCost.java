package Week2;


	import java.util.Scanner;

	public class TotalCost {
	    public static void main(String[] args) {
	        // Create a Scanner object for user input
	        Scanner scanner = new Scanner(System.in);

	        // Prompt the user to enter the quantity of items
	        System.out.print("Enter the quantity of items: ");
	        int quantity = scanner.nextInt();

	        // Prompt the user to enter the price per item
	        System.out.print("Enter the price per item: ");
	        double pricePerItem = scanner.nextDouble();

	        // Calculate the total cost
	        double totalCost = quantity * pricePerItem;

	        // Display the result
	        System.out.printf("The total cost is: %.2f\n", totalCost);

	        // Close the scanner
	        scanner.close();
	    }
	}

