package Week2;

public class Variable {
	
	    public static void main(String[] args) {
	        // Assign the variable with escaped double quotes
	        String message = "Hey there,\nI am \"some data\"!";
	        
	        // Print the variable
	        System.out.println(message);
	    }
}
	
