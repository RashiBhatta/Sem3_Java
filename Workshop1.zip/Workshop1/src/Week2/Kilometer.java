package Week2;


	import java.util.Scanner;
	public class Kilometer {

	
	    public static void main(String[] args) {
	        // Create a Scanner object for user input
	        Scanner scanner = new Scanner(System.in);

	        // Prompt the user to enter the distance in miles
	        System.out.print("Enter the distance in miles: ");
	        double miles = scanner.nextDouble();

	        // Convert miles to kilometers (1 mile = 1.60934 kilometers)
	        double kilometers = miles * 1.60934;

	        // Display the equivalent distance in kilometers
	        System.out.printf("The equivalent distance in kilometers is: %.2f\n", kilometers);

	        // Close the scanner
	        scanner.close();
	    }



}
