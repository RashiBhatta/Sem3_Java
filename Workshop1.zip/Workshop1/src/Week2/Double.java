package Week2;

public class Double {
	
	    public static void main(String[] args) {
	        // Declare variables
	        int myInt = 25;
	        double myDouble = 5.67;
	        char myChar = 'A';

	        // Print variables
	        System.out.println("Integer: " + myInt);
	        System.out.println("Double: " + myDouble);
	        System.out.println("Character: " + myChar);
	    }
	}

