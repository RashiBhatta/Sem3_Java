package Week2;

public class Area {
	
	    public static void main(String[] args) {
	        // Triangle side lengths
	        double a = 5;
	        double b = 6;
	        double c = 7;

	        // Calculate semi-perimeter
	        double s = (a + b + c) / 2;

	        // Calculate area using Heron's Formula
	        double area = Math.sqrt(s * (s - a) * (s - b) * (s - c));

	        // Print the area
	        System.out.println("Area of the triangle: " + area);
	    }
	}


