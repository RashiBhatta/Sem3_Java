package Week2;


	import java.util.Scanner;
	
	public class Temperature {

	    public static void main(String[] args) {
	        // Create a Scanner object for user input
	        Scanner scanner = new Scanner(System.in);

	        // Prompt the user to enter the temperature in Celsius
	        System.out.print("Enter temperature in Celsius: ");
	        double celsius = scanner.nextDouble();

	     
	        double fahrenheit = celsius * 9.0 / 5.0 + 32;

	        // Display the result
	        System.out.printf("Temperature in Fahrenheit: %.2f\n", fahrenheit);
	    }
	}
	        


