package Week2;

	import java.util.Scanner;

	public class SimpleInterest {
	    public static void main(String[] args) {
	        // Create a Scanner object for user input
	        Scanner scanner = new Scanner(System.in);

	        // Prompt the user to enter the principal amount
	        System.out.print("Enter the principal amount: ");
	        double principal = scanner.nextDouble();

	        // Prompt the user to enter the rate of interest
	        System.out.print("Enter the rate of interest (as a percentage): ");
	        double rate = scanner.nextDouble();

	        // Prompt the user to enter the time period (in years)
	        System.out.print("Enter the time period (in years): ");
	        double time = scanner.nextDouble();

	        // Calculate the simple interest using the formula
	        double interest = (principal * rate * time) / 100;

	        // Display the interest amount
	        System.out.printf("The simple interest is: %.2f\n", interest);
	        
	        // Close the scanner
	        scanner.close();

}
	}
